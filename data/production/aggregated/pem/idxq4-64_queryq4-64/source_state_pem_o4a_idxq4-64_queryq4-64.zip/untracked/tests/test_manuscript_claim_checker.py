from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = (
    ROOT / "paper_draft" / "v6_paper" / "tools" / "check_manuscript_claims.py"
)
SPEC = importlib.util.spec_from_file_location("check_manuscript_claims", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
CHECKER = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = CHECKER
SPEC.loader.exec_module(CHECKER)


def _contract() -> dict:
    return {
        "manuscript_contract": {
            "forbidden_fragments": [
                "changes 41 apparent positives to 12 confirmed endpoints"
            ],
            "required_fragments_all": ["48", "10"],
            "required_scope_terms": ["boundary-conditioned"],
        }
    }


def test_checker_rejects_legacy_pem_sentence() -> None:
    text = """
    The boundary-conditioned sample is reported. A quiet null
    changes 41 apparent positives to 12 confirmed endpoints. Values 48 and 10.
    """
    findings = CHECKER.check_text("fixture", text, _contract())
    assert any(item.kind == "forbidden" for item in findings)


def test_checker_accepts_current_counts_and_scope() -> None:
    text = """
    The boundary-conditioned sample is reported. The time-shift endpoint has
    48 positives, of which 10 survive the two-null rule.
    """
    assert CHECKER.check_text("fixture", text, _contract()) == []


def test_normalization_catches_line_wrapped_fragment() -> None:
    text = """
    changes 41 apparent positives
    to 12 confirmed endpoints; values 48 and 10 are also shown in a table.
    The analysis is boundary-conditioned.
    """
    findings = CHECKER.check_text("fixture", text, _contract())
    assert [item.kind for item in findings] == ["forbidden"]


def test_master_contract_artifact_hashes_are_current() -> None:
    contract = CHECKER.load_contract(CHECKER.DEFAULT_CONTRACT)
    assert CHECKER.verify_artifact_hashes(contract) == []
